/**
 * Prelab for Lab 2 of CS 1440.
 * @author Willow Sapphire
 * @version 06/13/2019
 */
public class Style 
{
    /**
     * @param args unused
     */
    public static void main(String[] args) 
    {
        int x = 1;
        int y = 2;
        System.out.println("x+y=" + (x + y));
    }
}
