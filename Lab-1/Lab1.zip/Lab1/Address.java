/**
 * Activity 1 for Lab 1 of CS 1440
 *
 * @author Willow Sapphire
 * @version 6/6/2019
 */
public class Address
{
   public static void main (String[] args) 
   {
       int number = 123;
       String street = "Main Street";
       String city = "Hickory";
       String state = "NC";
       int zip = 28601;
       System.out.println(number + " "
           + street + '\n'
           + city + ", "
           + state + " "
           + zip
       );
   }
}
